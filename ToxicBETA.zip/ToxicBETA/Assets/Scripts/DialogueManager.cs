using UnityEngine;
using TMPro;
using UnityEngine.UI;
using System;

[System.Serializable]
public class DialogueLine
{
    public string speakerName;
    [TextArea(2, 5)]
    public string text;
    public Sprite leftPortrait;
    public Sprite rightPortrait;
    public bool speakerIsLeft;
}

public class DialogueManager : MonoBehaviour
{
    [Header("UI References")]
    public TMP_Text characterNameText;
    public TMP_Text dialogueText;
    public Image portraitLeft;
    public Image portraitRight;
    public GameObject dialoguePanel;

    [Header("External Systems")]
    public DiarySystem diarySystem;

    [Header("Dialogue Data")]
    private DialogueLine[] dialogueLines;
    private int currentLine = 0;

    public Action OnDialogueEnd;

    // Inicia o di�logo com v�rias linhas
    public void StartDialogue(DialogueLine[] lines)
    {
        dialogueLines = lines;
        currentLine = 0;
        dialoguePanel.SetActive(true);
        ShowLine();
    }

    void ShowLine()
    {
        DialogueLine line = dialogueLines[currentLine];

        // Atualiza retratos
        portraitLeft.sprite = line.leftPortrait;
        portraitRight.sprite = line.rightPortrait;

        // Destaque do personagem que fala
        if (line.speakerIsLeft)
        {
            portraitLeft.color = new Color(1, 1, 1, 1f);     // vis�vel
            portraitRight.color = new Color(1, 1, 1, 0.5f);  // opaco
        }
        else
        {
            portraitLeft.color = new Color(1, 1, 1, 0.5f);
            portraitRight.color = new Color(1, 1, 1, 1f);
        }

        // Atualiza texto e nome
        characterNameText.text = line.speakerName;
        dialogueText.text = line.text;

        // Salva no di�rio
        diarySystem?.AddEntry($"{line.speakerName}: {line.text}");
    }

    public void NextDialogue()
    {
        if (dialogueLines == null) return;

        currentLine++;
        if (currentLine < dialogueLines.Length)
            ShowLine();
        else
            EndDialogue();
    }

    void EndDialogue()
    {
        dialoguePanel.SetActive(false);
        OnDialogueEnd?.Invoke();
    }
}
