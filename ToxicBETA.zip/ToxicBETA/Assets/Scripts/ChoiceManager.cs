using UnityEngine;
using TMPro;
using UnityEngine.UI;
using System;

public class ChoiceManager : MonoBehaviour
{
    public GameObject choicePrefab;
    public Transform choiceContainer;
    public Action<string> OnChoiceSelected;

    public void ShowChoices(string[] options)
    {
        foreach (Transform t in choiceContainer) Destroy(t.gameObject);

        foreach (var opt in options)
        {
            var go = Instantiate(choicePrefab, choiceContainer);
            var tmp = go.GetComponentInChildren<TMP_Text>();
            tmp.text = opt;
            var btn = go.GetComponent<Button>();
            btn.onClick.AddListener(() => { OnChoiceSelected?.Invoke(opt); ClearChoices(); });
        }
    }

    void ClearChoices()
    {
        foreach (Transform t in choiceContainer) Destroy(t.gameObject);
    }
}
