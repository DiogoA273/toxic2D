using UnityEngine;

public class DialogueTrigger : MonoBehaviour
{
    public DialogueManager dialogueManager;
    public DialogueData dialogueData;

    void OnMouseDown()
    {
        dialogueManager.StartDialogue(dialogueData.lines);
    }
}
