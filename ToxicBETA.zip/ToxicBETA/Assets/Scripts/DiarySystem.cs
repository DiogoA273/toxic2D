using UnityEngine;
using TMPro;
using System.Collections.Generic;
using UnityEngine.UI;

public class DiarySystem : MonoBehaviour
{
    public Transform diaryContent; // Content (do ScrollView)
    public GameObject diaryEntryPrefab;
    private List<string> entries = new();

    // Adiciona entrada e faz Scroll para o topo (ou fundo)
    public void AddEntry(string text)
    {
        entries.Add(text);
        var obj = Instantiate(diaryEntryPrefab, diaryContent);
        var tmp = obj.GetComponentInChildren<TMP_Text>();
        if (tmp != null) tmp.text = text;

        // Rebuild layout immediate para garantir tamanho atualizado
        LayoutRebuilder.ForceRebuildLayoutImmediate(diaryContent.GetComponent<RectTransform>());

        // opcional: scroll para baixo (�ltima mensagem vis�vel)
        var scrollRect = diaryContent.GetComponentInParent<ScrollRect>();
        if (scrollRect != null)
        {
            // 0 = bottom, 1 = top (experimentar conforme anchor)
            scrollRect.verticalNormalizedPosition = 0f;
        }
    }
}
