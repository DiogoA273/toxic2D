﻿using UnityEngine;
using TMPro;
using UnityEngine.UI;
using System;
using System.Collections;

[System.Serializable]
public class DialogueLine
{
    public string speakerName;
    [TextArea(2, 5)]
    public string text;
    public Sprite leftPortrait;
    public Sprite rightPortrait;
    public bool speakerIsLeft;
}

public class DialogueManager : MonoBehaviour
{
    [Header("UI References")]
    public TMP_Text characterNameText;
    public TMP_Text dialogueText;
    public Image portraitLeft;
    public Image portraitRight;
    public GameObject dialoguePanel;
    public Button nextButton; // botão para avançar

    [Header("External Systems")]
    public DiarySystem diarySystem;

    [Header("Typewriter Settings")]
    public float typeSpeed = 0.03f; // velocidade do efeito de digitação

    private DialogueLine[] dialogueLines;
    private int currentLine = 0;
    private bool isTyping = false;
    private Coroutine typingCoroutine;

    public Action OnDialogueEnd;

    void Start()
    {
        dialoguePanel.SetActive(false);

        // Liga o botão Next (caso exista)
        if (nextButton != null)
            nextButton.onClick.AddListener(NextDialogue);
    }

    // Inicia o diálogo com várias linhas
    public void StartDialogue(DialogueLine[] lines)
    {
        dialogueLines = lines;
        currentLine = 0;
        dialoguePanel.SetActive(true);
        ShowLine();
    }

    void ShowLine()
    {
        DialogueLine line = dialogueLines[currentLine];

        // Atualiza retratos
        portraitLeft.sprite = line.leftPortrait;
        portraitRight.sprite = line.rightPortrait;

        // Destaque de quem fala
        if (line.speakerIsLeft)
        {
            portraitLeft.color = new Color(1, 1, 1, 1f);
            portraitRight.color = new Color(1, 1, 1, 0.5f);
        }
        else
        {
            portraitLeft.color = new Color(1, 1, 1, 0.5f);
            portraitRight.color = new Color(1, 1, 1, 1f);
        }

        // Atualiza texto e nome
        characterNameText.text = line.speakerName;

        // Inicia o efeito de digitação
        if (typingCoroutine != null)
            StopCoroutine(typingCoroutine);

        typingCoroutine = StartCoroutine(TypeText(line.text));

        // Salva no diário
        diarySystem?.AddEntry($"{line.speakerName}: {line.text}");
    }

    IEnumerator TypeText(string text)
    {
        isTyping = true;
        dialogueText.text = "";

        foreach (char c in text)
        {
            dialogueText.text += c;
            yield return new WaitForSeconds(typeSpeed);
        }

        isTyping = false;
    }

    public void NextDialogue()
    {
        // Se ainda está digitando → mostra texto completo
        if (isTyping)
        {
            StopCoroutine(typingCoroutine);
            dialogueText.text = dialogueLines[currentLine].text;
            isTyping = false;
            return;
        }

        // Avança para a próxima fala
        currentLine++;
        if (currentLine < dialogueLines.Length)
            ShowLine();
        else
            EndDialogue();
    }

    void EndDialogue()
    {
        dialoguePanel.SetActive(false);
        OnDialogueEnd?.Invoke();
    }

    void Update()
    {
        // Apenas tecla Espaço avança o diálogo
        if (dialoguePanel.activeSelf && Input.GetKeyDown(KeyCode.Space))
        {
            NextDialogue();
        }
    }
}
