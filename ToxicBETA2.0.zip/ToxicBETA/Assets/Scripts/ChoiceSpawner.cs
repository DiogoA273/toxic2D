using UnityEngine;

public class ChoiceSpawner : MonoBehaviour
{
    [Header("Refer�ncias")]
    public DialogueManager dialogueManager;

    [Header("Prefabs das escolhas")]
    public GameObject choicePrefab1;
    public GameObject choicePrefab2;

    [Header("Posi��es na tela")]
    public Vector2 choice1Position = new Vector2(-2f, -1f);
    public Vector2 choice2Position = new Vector2(2f, -1f);

    private bool spawned = false;

    void Start()
    {
        dialogueManager.OnDialogueEnd += SpawnChoices;
    }

    void SpawnChoices()
    {
        if (spawned) return;
        spawned = true;

        // Instancia os dois objetos com colliders ou bot�es
        Instantiate(choicePrefab1, choice1Position, Quaternion.identity);
        Instantiate(choicePrefab2, choice2Position, Quaternion.identity);
    }
}
