using UnityEngine;

public class KeyboardShortcuts : MonoBehaviour
{
    public GameObject diaryUI;
    public GameObject settingsUI;
    public DialogueManager dialogueManager;

    void Start()
    {
        // tenta achar automaticamente se n�o foi atribu�da no Inspector
        if (dialogueManager == null)
            dialogueManager = FindObjectOfType<DialogueManager>();
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Q) && diaryUI != null)
        {
            bool newState = !diaryUI.activeSelf;
            diaryUI.SetActive(newState);
            if (newState && settingsUI != null) settingsUI.SetActive(false);
        }

        if (Input.GetKeyDown(KeyCode.Escape) && settingsUI != null)
        {
            bool newState = !settingsUI.activeSelf;
            settingsUI.SetActive(newState);
            if (newState && diaryUI != null) diaryUI.SetActive(false);
        }

        if (Input.GetKeyDown(KeyCode.Space))
        {
            if (dialogueManager != null)
                dialogueManager.NextDialogue();
            else
                Debug.LogWarning("DialogueManager n�o atribu�do (KeyboardShortcuts).");
        }
    }
}
