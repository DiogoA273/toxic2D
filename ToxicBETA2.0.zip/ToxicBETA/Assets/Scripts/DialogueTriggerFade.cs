using UnityEngine;
using System.Collections;

[RequireComponent(typeof(SpriteRenderer))]
public class DialogueTriggerFade : MonoBehaviour
{
    [Header("Refer�ncias")]
    public DialogueManager dialogueManager;
    public DialogueData dialogueData;

    [Header("Configura��o")]
    public float fadeDuration = 0.5f; // tempo do fade em segundos
    public bool disableAfterFade = true; // se deve desativar o objeto ao final

    private SpriteRenderer spriteRenderer;
    private bool hasInteracted = false;

    void Awake()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
    }

    void OnMouseDown()
    {
        if (hasInteracted) return;
        if (dialogueManager == null || dialogueData == null) return;

        hasInteracted = true;
        StartCoroutine(FadeOutAndStartDialogue());
    }

    IEnumerator FadeOutAndStartDialogue()
    {
        Color originalColor = spriteRenderer.color;
        float elapsedTime = 0f;

        while (elapsedTime < fadeDuration)
        {
            float alpha = Mathf.Lerp(1f, 0f, elapsedTime / fadeDuration);
            spriteRenderer.color = new Color(originalColor.r, originalColor.g, originalColor.b, alpha);
            elapsedTime += Time.deltaTime;
            yield return null;
        }

        // Garante que fique totalmente invis�vel
        spriteRenderer.color = new Color(originalColor.r, originalColor.g, originalColor.b, 0f);

        if (disableAfterFade)
            gameObject.SetActive(false);

        // Agora inicia o di�logo
        dialogueManager.StartDialogue(dialogueData.lines);
    }
}
