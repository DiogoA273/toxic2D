using UnityEngine;
using UnityEngine.UI;

public class DialogueTriggerButton : MonoBehaviour
{
    public DialogueManager dialogueManager;
    public DialogueData dialogueData;

    void Start()
    {
        GetComponent<Button>().onClick.AddListener(() =>
        {
            dialogueManager.StartDialogue(dialogueData.lines);
            Destroy(gameObject); // remove o bot�o ap�s clicar
        });
    }
}
