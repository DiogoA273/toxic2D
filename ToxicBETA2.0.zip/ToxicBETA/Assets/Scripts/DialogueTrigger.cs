using UnityEngine;

public class DialogueTrigger : MonoBehaviour
{
    [Header("Refer�ncias")]
    public DialogueManager dialogueManager;
    public DialogueData dialogueData;

    [Header("Configura��o")]
    public bool disableOnClick = true; // se o objeto deve sumir imediatamente

    private bool hasInteracted = false;

    void OnMouseDown()
    {
        if (hasInteracted) return;
        if (dialogueManager == null || dialogueData == null) return;

        hasInteracted = true;

        // Some imediatamente ao clicar
        if (disableOnClick)
            gameObject.SetActive(false);

        // Inicia o di�logo
        dialogueManager.StartDialogue(dialogueData.lines);
    }
}
