using UnityEngine;

[CreateAssetMenu(fileName = "NovoDi�logo", menuName = "Di�logo/Novo Di�logo")]
public class DialogueData : ScriptableObject
{
    public DialogueLine[] lines;
}
