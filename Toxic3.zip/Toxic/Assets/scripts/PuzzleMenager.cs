using UnityEngine;

public class PuzzleActivator : MonoBehaviour
{
    [SerializeField] private PuzzleGame puzzleGame;

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            puzzleGame.ShowPuzzle();
        }
    }
}

