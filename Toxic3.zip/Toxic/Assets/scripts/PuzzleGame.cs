using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class PuzzleGame : MonoBehaviour
{
    [Header("UI References")]
    [SerializeField] private GameObject buttonPrefab;
    [SerializeField] private Transform boardParent;
    [SerializeField] private float padding = 10f;
    [SerializeField] private float moveDuration = 0.2f;

    private Button[,] buttons = new Button[3, 3];
    private int[,] grid = new int[3, 3];
    private int emptyRow = 2;
    private int emptyCol = 2;
    [HideInInspector] public bool puzzleActive = false;

    void Start()
    {
        InitGrid();
        HidePuzzle();
    }

    void InitGrid()
    {
        float parentWidth = ((RectTransform)boardParent).rect.width;
        float parentHeight = ((RectTransform)boardParent).rect.height;
        float buttonSize = Mathf.Min((parentWidth - padding * 2) / 3, (parentHeight - padding * 2) / 3);

        // Calcula deslocamento para centralizar
        float totalWidth = 3 * buttonSize + 2 * padding;
        float totalHeight = 3 * buttonSize + 2 * padding;
        Vector2 offset = new Vector2(-totalWidth / 2 + buttonSize / 2, totalHeight / 2 - buttonSize / 2);

        int num = 1;
        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 3; j++)
            {
                GameObject btnObj = Instantiate(buttonPrefab, boardParent);
                btnObj.name = $"Tile_{i}_{j}";
                RectTransform rt = btnObj.GetComponent<RectTransform>();
                rt.sizeDelta = new Vector2(buttonSize, buttonSize);

                // Centraliza o grid
                rt.anchoredPosition = new Vector2(j * (buttonSize + padding), -i * (buttonSize + padding)) + offset;

                Button btn = btnObj.GetComponent<Button>();
                int row = i, col = j;
                btn.onClick.AddListener(() => OnTileClick(row, col));

                buttons[i, j] = btn;
                grid[i, j] = num++;
            }
        }
        grid[2, 2] = 0; // espa�o vazio
    }

    public void ShowPuzzle()
    {
        if (puzzleActive) return;
        puzzleActive = true;
        boardParent.gameObject.SetActive(true);
        ShuffleGrid();
        UpdateUI();
    }

    void HidePuzzle()
    {
        puzzleActive = false;
        boardParent.gameObject.SetActive(false);
    }

    void ShuffleGrid()
    {
        for (int i = 0; i < 100; i++)
        {
            int dir = Random.Range(0, 4);
            switch (dir)
            {
                case 0: TryMove(emptyRow - 1, emptyCol); break;
                case 1: TryMove(emptyRow + 1, emptyCol); break;
                case 2: TryMove(emptyRow, emptyCol - 1); break;
                case 3: TryMove(emptyRow, emptyCol + 1); break;
            }
        }
    }

    void UpdateUI()
    {
        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 3; j++)
            {
                Text txt = buttons[i, j].GetComponentInChildren<Text>();
                RectTransform rt = buttons[i, j].GetComponent<RectTransform>();
                Vector2 targetPos = new Vector2(j * (rt.sizeDelta.x + padding), -i * (rt.sizeDelta.y + padding));

                // Aplica offset centralizado
                float totalWidth = 3 * rt.sizeDelta.x + 2 * padding;
                float totalHeight = 3 * rt.sizeDelta.y + 2 * padding;
                Vector2 offset = new Vector2(-totalWidth / 2 + rt.sizeDelta.x / 2, totalHeight / 2 - rt.sizeDelta.y / 2);
                targetPos += offset;

                if (grid[i, j] == 0)
                {
                    txt.text = "";
                    buttons[i, j].GetComponent<Image>().color = Color.gray;
                }
                else
                {
                    txt.text = grid[i, j].ToString();
                    buttons[i, j].GetComponent<Image>().color = Color.white;
                }

                StartCoroutine(MoveButton(rt, targetPos, moveDuration));
            }
        }
    }

    IEnumerator MoveButton(RectTransform rt, Vector2 target, float duration)
    {
        Vector2 start = rt.anchoredPosition;
        float elapsed = 0f;
        while (elapsed < duration)
        {
            rt.anchoredPosition = Vector2.Lerp(start, target, elapsed / duration);
            elapsed += Time.deltaTime;
            yield return null;
        }
        rt.anchoredPosition = target;
    }

    void OnTileClick(int row, int col)
    {
        if (!puzzleActive) return;

        if (IsAdjacent(row, col))
        {
            TryMove(row, col);
            UpdateUI();

            if (IsSolved())
            {
                Debug.Log("Parab�ns! Puzzle resolvido!");
                HidePuzzle();
            }
        }
    }

    bool IsAdjacent(int row, int col)
    {
        int dr = Mathf.Abs(row - emptyRow);
        int dc = Mathf.Abs(col - emptyCol);
        return (dr + dc == 1);
    }

    void TryMove(int row, int col)
    {
        if (row >= 0 && row < 3 && col >= 0 && col < 3)
        {
            grid[emptyRow, emptyCol] = grid[row, col];
            grid[row, col] = 0;
            emptyRow = row;
            emptyCol = col;
        }
    }

    bool IsSolved()
    {
        int expected = 1;
        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 3; j++)
            {
                if (i == 2 && j == 2) return grid[i, j] == 0;
                if (grid[i, j] != expected++) return false;
            }
        return true;
    }
}

